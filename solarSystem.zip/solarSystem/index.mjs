import express from 'express';
const solarSystem = (await import('npm-solarsystem')).default;

const app = express();
app.set("view engine", "ejs");
app.use(express.static("public"));

//root route
app.get('/', (req, res) => {
   res.render('home.ejs')
});

app.get('/planet', (req, res) => {
   let planet_name = req.query.planetName;
   let planetInfo = solarSystem[`get${planet_name}`]();
   res.render('planetInfo.ejs', {planetInfo, planet_name});
});

app.listen(3000, () => {
   console.log('server started');
});